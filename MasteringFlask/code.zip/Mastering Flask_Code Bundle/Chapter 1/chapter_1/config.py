class DevConfig(object):
    DEBUG = True
