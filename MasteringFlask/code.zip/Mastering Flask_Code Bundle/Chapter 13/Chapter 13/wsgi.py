from webapp import create_app

app = create_app("webapp.config.ProdConfig")
