from webapp import create_app

application = create_app("webapp.config.ProdConfig")
